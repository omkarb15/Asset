﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UserInformation.Model;

namespace UserInformation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly UserContext _context;

        
            public UsersController (UserContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult <IEnumerable<Asset>>> Getall()
        {
            return await _context.Assets.ToListAsync();
        }



      
        [HttpPost]
        public async Task<ActionResult<Asset>> adduser( [FromForm]Asset asset, [FromForm] IFormFile file , [FromForm] List<int> hobbyIds)
        {

            if(file !=null && file.Length> 0)
            {
                var uploadFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                if (!Directory.Exists(uploadFolder))
                {
                    Directory.CreateDirectory(uploadFolder);
                }
                var fileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
                var filePath = Path.Combine(uploadFolder, fileName);

                using( var stream= new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }
                var imageUrl = $"{Request.Scheme}://{Request.Host}/uploads/{fileName}";
                asset.ProfilImage = imageUrl;
            }

            await _context.Assets.AddAsync(asset);
            await _context.SaveChangesAsync();

            if (hobbyIds != null && hobbyIds.Any())
            {
                foreach (var hobbyId in hobbyIds)
                {
                    _context.AssetHobbies.Add(new AssetHobby { AssetId = asset.Id, HobbyId = hobbyId });
                }
                await _context.SaveChangesAsync();
            }
            return Ok(asset);

        }
        [HttpPut("{id}")]
        public async Task<ActionResult<Asset>> EditUser(int id, [FromForm] Asset asset, IFormFile? file) //? if user may or may not upload image , if not upload image then remain previous image there
        {
            var user = await _context.Assets.FindAsync(id);
            if (user == null)
            {
                return NotFound();
            }


            user.FirstName = asset.FirstName;
            user.SurName = asset.SurName;
            user.DOB = asset.DOB;
            user.Gender = asset.Gender;
            user.EmialId = asset.EmialId;
            user.UserName = asset.UserName;
            user.PassWord = asset.PassWord;

            
            if (file != null && file.Length > 0)
            {
               
                if (!string.IsNullOrEmpty(user.ProfilImage)) // to delete previous image from the folder
                {
                    var previousImagePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", Path.GetFileName(user.ProfilImage));// get the current directory of image and also GetFile- returns its name and extension
                    if (System.IO.File.Exists(previousImagePath))
                    {
                        System.IO.File.Delete(previousImagePath);
                    }
                }

                
                var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");// to create image for new user
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                var filename = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);
                var filepath = Path.Combine(uploadsFolder, filename);

                using (var stream = new FileStream(filepath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                var imageUrl = $"{Request.Scheme}://{Request.Host}/uploads/{filename}";
                user.ProfilImage = imageUrl; 

            }

            _context.Assets.Update(user);
            await _context.SaveChangesAsync();

            return Ok(user);
        }


    

        [HttpDelete("{id}")]
        public async Task<ActionResult>DeleteUser(int id)
        {
            var user = await _context.Assets.FindAsync(id);
            if (user == null)
            {
                return NotFound("user is not found");
            }
            if (!string.IsNullOrEmpty(user.ProfilImage))
            {
                var filepath = (Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", Path.GetFileName(user.ProfilImage))); // wwwroot folder is default root directory that serving ststic files
                //if (System.IO.File.Exists(filepath))
                //{
                //    System.IO.File.Delete(filepath);
                //}
                var fileinfo = new FileInfo(filepath);
                if (fileinfo.Exists) {
                    fileinfo.Delete();
                }
                
            }
            _context.Assets.Remove(user);
            await _context.SaveChangesAsync();
            return NoContent();


        }



    }



}

