﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace UserInformation.Model
{
    public class AssetHobby
    {

        [Key]
        public int Id { get; set; }

        [Required]
        public int AssetId { get; set; }
        [ForeignKey("AssetId")]
        public Asset Asset { get; set; }

        [Required]
        public int HobbyId { get; set; }
        [ForeignKey("HobbyId")]
        public Hobby Hobby { get; set; }

    }
}
