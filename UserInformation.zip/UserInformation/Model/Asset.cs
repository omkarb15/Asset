﻿using System.ComponentModel.DataAnnotations;

namespace UserInformation.Model
{
    public class Asset
    {
        [Required]
        public int Id { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string SurName { get; set; }
       
        public DateTime DOB { get; set; }
        [Required]
        public string Gender { get; set; }
        [Required,EmailAddress]
        public string EmialId { get; set; }
        [Required]
        public string UserName { get; set; }
        [Required, MinLength(4)]
        public string  PassWord { get; set; }

        public string? ProfilImage { get; set; }
        public ICollection<AssetHobby> AssetHobbies { get; set; } = new List<AssetHobby>();


    }
}
